# pasSecure
Chrome extension to help you pick a secure password.
